import React, {useState} from 'react';
import {View, Text, Dimensions} from 'react-native';

import {connect} from 'react-redux';

import {useTranslation} from '../../LanguageContext';
import {Images, Colors} from '../../Theme';
import {InputField, ButtonComponent} from '../../Components';
import {
  Wrapper,
  MainContainer,
  Image1,
  Welcomelabel,
  Loginlabel,
  FooterContaienr,
  FooterMainContaienr,
  Image2,
} from './style';

const LoginScreen = props => {
  const Language = useTranslation();

  return (
    <Wrapper>
      <MainContainer>
        <Image1 source={Images.WelcomeImage1} />
        <Welcomelabel>{Language.WelcomeLabel}</Welcomelabel>
        <Loginlabel>{Language.WelcomeTitle}</Loginlabel>
      </MainContainer>
      <FooterContaienr>
        <FooterMainContaienr>
          <ButtonComponent
            buttonText={Language.WelcomeButtonNext}
            buttonOnPress={() => props.navigation.navigate('Welcome2')}
            color={Colors.themeColor}
          />
        </FooterMainContaienr>
      </FooterContaienr>
    </Wrapper>
  );
};

export default connect()(LoginScreen);
