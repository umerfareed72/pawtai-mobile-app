import React, {useState} from 'react';
import {View, Text, Dimensions} from 'react-native';

import {connect} from 'react-redux';

import {useTranslation} from '../../LanguageContext';
import {Images, Colors} from '../../Theme';
import {InputField, ButtonComponent} from '../../Components';
import {
  Wrapper,
  MainContainer,
  Image1,
  Welcomelabel,
  Loginlabel,
  FooterContaienr,
  FooterMainContaienr,
  Image2,
} from './style';

const LoginScreen = props => {
  const Language = useTranslation();

  return (
    <Wrapper>
      <MainContainer>
        <Image2 source={Images.WelcomeImage3} />
        <Welcomelabel>{Language.WelcomeTextAddActivity}</Welcomelabel>
        <Loginlabel>{Language.WelcomeTextRecordActivity}</Loginlabel>
      </MainContainer>
      <FooterContaienr>
        <FooterMainContaienr>
          <ButtonComponent
            buttonText={Language.WelcomeButtonGetStarted}
            buttonOnPress={() => props.navigation.navigate('HomeScreen')}
            color={Colors.themeColor}
          />
        </FooterMainContaienr>
      </FooterContaienr>
    </Wrapper>
  );
};

export default connect()(LoginScreen);
